﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Windows.Forms;
using Ionic.Zip;
using Spire.Pdf;

namespace AutoPrintApp
{
    public partial class frmMain : Form
    {
        string _UserId = "";
        string _Pwd = "";
        string _CompanyCode = "";
        string _StoreNo = "";
        string _CurrentPrinter = "";
        ZipFile zipFile = null;
        System.IO.StreamReader txtFileToPrint;
        System.Drawing.Font printFont;

        public frmMain()
        {
            InitializeComponent();
        }

        private void ntfIcon_DoubleClick(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
        }

        private void mnuStartProcess_Click(object sender, EventArgs e)
        {
            btnStartPrintProcess.PerformClick();
        }

        private void mnuStopProcess_Click(object sender, EventArgs e)
        {
            btnStopPrintProcess.PerformClick();
        }

        private void mnuPrinterSetting_Click(object sender, EventArgs e)
        {
            frmPrinterSetting frmPrinterSetting = new frmPrinterSetting();
            frmPrinterSetting.ShowDialog();
        }

        private void mnuSystemExit_Click(object sender, EventArgs e)
        {
            mnuStopProcess.PerformClick();
            Application.Exit();
        }

        private void mnuLogout_Click(object sender, EventArgs e)
        {
            btnStopPrintProcess.PerformClick();
            mnuMain.Enabled = false;
            frmLogin frmLogin = new frmLogin();
            frmLogin.FormOpenMode = "LOG_OUT";
            frmLogin.ShowDialog();
            mnuMain.Enabled = true;
        }

        private void mnuChangeUser_Click(object sender, EventArgs e)
        {
            btnStopPrintProcess.PerformClick();
            mnuMain.Enabled = false;
            frmLogin frmLogin = new frmLogin();
            frmLogin.FormOpenMode = "CHANGE_USER";
            frmLogin.ShowDialog();
            mnuMain.Enabled = true;
        }

        private void tmPrintTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                //タイマーを中止して、ファイルのダウンロードと印刷を行う。
                tmPrintTimer.Stop();
                mnuMain.Enabled = false;

                string defaultPrinter = ConfigurationManager.AppSettings["CurrentPrinter"] + "";
                if (defaultPrinter != _CurrentPrinter) _CurrentPrinter = defaultPrinter;

                //新規データを確認する。
                AutoPrint.RegPrintData(_UserId, _CompanyCode, _StoreNo);

                //データをクライアント端末にダウンロードする。
                string fileDirOnLocal = ConfigurationManager.AppSettings["FileDirOnLocal"] + "";
                fileDirOnLocal = Application.StartupPath + @"\" + fileDirOnLocal;
                string localZipFile = fileDirOnLocal + @"\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".zip";
                AutoPrint.DownloadFile(_CompanyCode, _StoreNo, localZipFile);

                //ダウンロードされたファイルの容量を確認する。
                FileInfo fi = new FileInfo(localZipFile);
                if(fi.Length > 0)
                {
                    //各ファイルを印刷し、印刷済み状態を更新し、印刷したファイルを削除する。
                    string fileDirOnServer = ConfigurationManager.AppSettings["FileDirOnServer"] + "";
                    string extractedFileDir = fileDirOnLocal + fileDirOnServer;
                    extractedFileDir = extractedFileDir.Replace("{cocode}", _CompanyCode);
                    extractedFileDir = extractedFileDir.Replace("{storeno}", _StoreNo);

                    //クライアント端末にダウンロードされたZipファイルを解凍する。
                    zipFile = new ZipFile(localZipFile);
                    zipFile.ExtractAll(extractedFileDir, ExtractExistingFileAction.DoNotOverwrite);

                    //解凍されたZipファイルを他のフォルダーに移動する。
                    string fdlc = ConfigurationManager.AppSettings["FileDirOnLocal"] + "";
                    string pfdlc = ConfigurationManager.AppSettings["PrintedFileDirOnLocal"] + "";
                    string newLocalFile = localZipFile.Replace(fdlc, pfdlc);
                    zipFile.Dispose();
                    File.Move(localZipFile, newLocalFile);

                    //EDIT HUNGNT 2016/05/24 >>> Không cho phép in file txt + PDF, chỉ in file PDF
                    //string[] files = Directory.GetFiles(extractedFileDir, "*.txt");
                    //foreach (string txtFile in files)
                    //{
                    //    //テキストファイルを印刷する。
                    //    txtFileToPrint = new System.IO.StreamReader(txtFile);
                    //    printFont = new System.Drawing.Font("Arial", 10);
                    //    pdPrintDocument.PrinterSettings.PrinterName = _CurrentPrinter;
                    //    pdPrintDocument.Print();
                    //    txtFileToPrint.Close();

                    //    AutoPrint.UpdatePrintData(_UserId, _CompanyCode, _StoreNo, Path.GetFileName(txtFile));
                    //    File.Delete(txtFile);

                    //    try
                    //    {
                    //        //PDFファイルを印刷する。
                    //        PdfDocument doc = new PdfDocument();
                    //        string pdfFile = txtFile.Replace(".txt", ".pdf");

                    //        if (File.Exists(pdfFile))
                    //        {
                    //            doc.LoadFromFile(pdfFile);
                    //            doc.PrintFromPage = 1;
                    //            doc.PrintToPage = doc.Pages.Count;
                    //            doc.PrinterName = _CurrentPrinter;
                    //            PrintDocument printDoc = doc.PrintDocument;
                    //            printDoc.Print();

                    //            AutoPrint.UpdatePrintData(_UserId, _CompanyCode, _StoreNo, Path.GetFileName(pdfFile));
                    //            File.Delete(pdfFile);
                    //        }
                    //    }
                    //    catch (Exception ex) { }
                    //}

                    string[] pdfFiles = Directory.GetFiles(extractedFileDir, "*.pdf");
                    foreach (string pdfFile in pdfFiles)
                    {
                        try
                        {
                            //PDFファイルを印刷する。
                            PdfDocument doc = new PdfDocument();
                            doc.LoadFromFile(pdfFile);
                            doc.PrintFromPage = 1;
                            doc.PrintToPage = doc.Pages.Count;
                            doc.PrinterName = _CurrentPrinter;
                            PrintDocument printDoc = doc.PrintDocument;
                            printDoc.Print();

                            AutoPrint.UpdatePrintData(_UserId, _CompanyCode, _StoreNo, Path.GetFileName(pdfFile));
                            File.Delete(pdfFile);
                        }
                        catch (Exception ex) { }
                    }
                    //<<< EDIT HUNGNT 2016/05/24
                }
                else
                {
                    //印刷内容がないZipファイルを削除する。
                    File.Delete(localZipFile);
                }

                ////Thực hiện in nốt các file pdf còn tồn tại (do không có file .txt cùng tên)
                //string[] pdfFiles = Directory.GetFiles(extractedFileDir, "*.pdf");
                //foreach (string pdfFile in pdfFiles)
                //{
                //    try
                //    {
                //        //PDFファイルを印刷する。
                //        PdfDocument doc = new PdfDocument();
                //        doc.LoadFromFile(pdfFile);
                //        doc.PrintFromPage = 1;
                //        doc.PrintToPage = doc.Pages.Count;
                //        doc.PrinterName = _CurrentPrinter;
                //        PrintDocument printDoc = doc.PrintDocument;
                //        printDoc.Print();

                //        AutoPrint.UpdatePrintData(_UserId, _CompanyCode, _StoreNo, Path.GetFileName(pdfFile));
                //        File.Delete(pdfFile);
                //    }
                //    catch (Exception ex) { }
                //}

                //印刷したファイルと4日前のデータを削除します。
                AutoPrint.DeletePrintedFile(_CompanyCode, _StoreNo);
            }
            catch (Exception ex) {}
            finally
            {
                //メニューを再表示し、タイマーを再起動する。
                tmPrintTimer.Start();
                mnuMain.Enabled = true;
            }
        }

        private bool CheckPrinterAvailable()
        {
            _CurrentPrinter = ConfigurationManager.AppSettings["CurrentPrinter"] + "";
            return true;
        }

        private void pdPrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            float yPos = 0f;
            int count = 0;
            float leftMargin = e.MarginBounds.Left;
            float topMargin = e.MarginBounds.Top;
            string line = null;
            float linesPerPage = e.MarginBounds.Height / printFont.GetHeight(e.Graphics);
            while (count < linesPerPage)
            {
                line = txtFileToPrint.ReadLine();
                if (line == null)
                {
                    break;
                }
                yPos = topMargin + count * printFont.GetHeight(e.Graphics);
                e.Graphics.DrawString(line, printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
                count++;
            }
            if (line != null)
            {
                e.HasMorePages = true;
            }
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == WindowState)
                Hide();
        }

        private void frmMain_Shown(object sender, EventArgs e)
        {
            frmLogin frmLogin = new frmLogin();
            frmLogin.ShowDialog();

            //アプリケーションのタイトル
            string AppTitle = ConfigurationManager.AppSettings["ApplicationTitle"] + "  " + "自動印刷ソフト";
            this.Text = AppTitle;

            txtStartProcess.Clear();
            txtStartProcess.AppendText("自動印刷処理を開始する場合は" + Environment.NewLine);
            txtStartProcess.AppendText("下のボタンを押してください。");

            txtStopProcess.Clear();
            txtStopProcess.AppendText("自動印刷処理を終了する場合は" + Environment.NewLine);
            txtStopProcess.AppendText("下のボタンを押してください。");

            //最後にログインしたユーザーの情報を取得する
            _UserId = frmLogin.LoginId;
            _Pwd = frmLogin.LoginPwd;
            _CurrentPrinter = ConfigurationManager.AppSettings["CurrentPrinter"] + "";

            if(_CurrentPrinter.Trim() != "")
            {
                //Trường hợp đã thiết lập máy in
                btnStartPrintProcess.Visible = true;
                txtStartProcess.Visible = true;
                mnuStartProcess.Enabled = true;
                mnuStopProcess.Enabled = false;
            }
            else 
            {
                //Trường hợp chưa thiết lập máy in thì thông báo
                btnStartPrintProcess.Visible = false;
                txtStartProcess.Visible = false;
                mnuStartProcess.Enabled = false;
                MessageBox.Show("プリンタ設定してください。", "システム警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                frmPrinterSetting frmPrinterSetting = new frmPrinterSetting();
                frmPrinterSetting.ShowDialog();
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.WindowsShutDown) return;
            if (e.CloseReason == CloseReason.ApplicationExitCall) return;

            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (MessageBox.Show("自動印刷ソフトを完了します。よろしいですか？", "終了を確認します", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == System.Windows.Forms.DialogResult.Cancel)
                    e.Cancel = true;
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            try
            {
                string CurrentSeason = "Winter";
                string IconPath = Application.StartupPath + @"\winter.png";
                String SpringStartFrom = ConfigurationManager.AppSettings["Spring"] + "/" + System.DateTime.Now.Year.ToString();
                String SummerStartFrom = ConfigurationManager.AppSettings["Summer"] + "/" + System.DateTime.Now.Year.ToString();
                String AutumnStartFrom = ConfigurationManager.AppSettings["Autumn"] + "/" + System.DateTime.Now.Year.ToString();
                String WinterStartFrom = ConfigurationManager.AppSettings["Winter"] + "/" + System.DateTime.Now.Year.ToString();

                if (System.DateTime.Now >= Convert.ToDateTime(SpringStartFrom)) CurrentSeason = "Spring";
                if (System.DateTime.Now >= Convert.ToDateTime(SummerStartFrom)) CurrentSeason = "Summer";
                if (System.DateTime.Now >= Convert.ToDateTime(AutumnStartFrom)) CurrentSeason = "Autumn";
                if (System.DateTime.Now >= Convert.ToDateTime(WinterStartFrom)) CurrentSeason = "Winter";

                switch (CurrentSeason)
                {
                    case "Spring":
                        IconPath = Application.StartupPath + @"\spring.png";
                        break;
                    case "Summer":
                        IconPath = Application.StartupPath + @"\summer.png";
                        break;
                    case "Autumn":
                        IconPath = Application.StartupPath + @"\autumn.png";
                        break;
                    case "Winter":
                        IconPath = Application.StartupPath + @"\winter.png";
                        break;
                }

                this.BackgroundImage = Image.FromFile(IconPath);
            }
            catch (Exception ex) { }
        }

        private void btnStartPrintProcess_Click(object sender, EventArgs e)
        {
            //プリンタをチェックする
            string defaultPrinter = ConfigurationManager.AppSettings["CurrentPrinter"] + "";
            if (defaultPrinter == "")
            {
                MessageBox.Show("システムに印刷をまだ設定していません。「プリンタ設定」メニューにクリックし、プリンタを選択してください。", "システム警告", MessageBoxButtons.OK, MessageBoxIcon.Error);
                frmPrinterSetting frmPrinterSetting = new frmPrinterSetting();
                frmPrinterSetting.ShowDialog();
                return;
            }

            //ログインに成功した後、メニューを有効にする。
            mnuMain.Enabled = true;
            mnuStartProcess.Enabled = false;
            mnuStopProcess.Enabled = true;
            btnStartPrintProcess.Visible = false;
            txtStartProcess.Visible = false;
            btnStopPrintProcess.Visible = true;
            txtStopProcess.Visible = true;

            //ユーザIDから会社コードと薬局コードを分岐する。
            _CompanyCode = _UserId.Substring(0, 5);
            _StoreNo = _UserId.Substring(5, 5);

            //サーバでデータのスキャン、ダウンロード、印刷を自動的に行う。
            int iTimerInterval = Convert.ToInt32(ConfigurationManager.AppSettings["PrintInterval"]);
            tmPrintTimer.Enabled = true;
            tmPrintTimer.Interval = iTimerInterval;
            tmPrintTimer.Start();

            //Minimize app into taskbar
            Hide();
        }

        private void btnStopPrintProcess_Click(object sender, EventArgs e)
        {
            tmPrintTimer.Stop();
            tmPrintTimer.Enabled = false;

            //メニューを有効にする。
            mnuMain.Enabled = true;
            mnuStartProcess.Enabled = true;
            mnuStopProcess.Enabled = false;
            btnStartPrintProcess.Visible = true;
            txtStartProcess.Visible = true;
            btnStopPrintProcess.Visible = false;
            txtStopProcess.Visible = false;
        }
    }
}
